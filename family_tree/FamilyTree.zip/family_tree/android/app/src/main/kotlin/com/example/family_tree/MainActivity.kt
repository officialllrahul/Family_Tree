package com.example.family_tree

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
