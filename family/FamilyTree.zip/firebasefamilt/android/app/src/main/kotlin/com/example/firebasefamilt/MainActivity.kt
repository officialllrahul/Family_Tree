package com.example.firebasefamilt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
