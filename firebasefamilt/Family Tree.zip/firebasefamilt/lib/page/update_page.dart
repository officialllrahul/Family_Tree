import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controller/controller_page.dart';
import '../ui_helper.dart';

class UpdatePage extends StatefulWidget {
  const UpdatePage({super.key});

  @override
  State<UpdatePage> createState() => _UpdatePageState();
}

class _UpdatePageState extends State<UpdatePage> {

  var updateNameCtrl = TextEditingController();
  var updateAgeCtrl = TextEditingController();
  var updateRelationShipCtrl = TextEditingController();

  final HomePageController _homePageController = Get.put(HomePageController());

  String? selectedValue;
  List<String> familyRelation = [
    'Father',
    'Mother',
    'Son',
    'Daughter'
  ];


  @override
  void initState() {
    super.initState();
    updateNameCtrl.text = Get.arguments['name'];
    updateAgeCtrl.text = Get.arguments['age'];
    selectedValue = Get.arguments['relationship'];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Update Page',style: TextStyle(color: Colors.white),),
        centerTitle: true,
        backgroundColor: Colors.blue,
      ),
      body: Container(
        margin: EdgeInsets.all(19),
        child: Column(
          children: [
            UiHelper.customeTextFiled(updateNameCtrl, 'Enter name',TextInputType.text),
            SizedBox(height: MediaQuery.sizeOf(context).height * .008,),
            UiHelper.customeTextFiled(updateAgeCtrl, 'Enter age',TextInputType.number),
            SizedBox(height: MediaQuery.sizeOf(context).height * .008,),
            DropdownButtonFormField(
              decoration: InputDecoration(
                labelText: Get.arguments['relationship'],
              ),
              items: familyRelation.map((items){
                return DropdownMenuItem(
                  value: items,
                  child: Text(items),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  selectedValue = value;
                });
              },
            ),
            SizedBox(height: MediaQuery.sizeOf(context).height * .008,),
            UiHelper.customeElevatedButton(() {
              _homePageController.updateFamilyData(Get.arguments['id'], updateNameCtrl.text, updateAgeCtrl.text.toString(), selectedValue.toString());
            }, 'Update')
          ],
        ),
      ),
    );
  }
}
